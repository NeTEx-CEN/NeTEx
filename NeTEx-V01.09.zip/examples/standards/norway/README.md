# netex-norway-examples

Examples for the Norwegian NeTEx profile

The profile can be found here (in Norwegian):
https://rutebanken.atlassian.net/wiki/display/PUBLIC/NeTEx+profil+Norge
